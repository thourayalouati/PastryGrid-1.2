package messages;

import java.io.IOException;
import java.util.Vector;

import principal.ApplicationPastryGrid;
import principal.NodePastryGrid;
import principal.Requirements;
import principal.TaskPastryGrid;

import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.NodeHandle;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;
import rice.pastry.PastryNode;
import rice.pastry.leafset.LeafSet;

import java.io.File;

import java.io.FileOutputStream;

import java.io.IOException;


public class ApplicationReceived extends MessagePastryGrid {

	private static final long serialVersionUID = 1L;
	public static final short TYPE = 17; // 4

	public ApplicationReceived(NodeHandle from, String appName, String time) {
		super(from, appName, time);

	}

	public ApplicationReceived(InputBuffer buf, Endpoint endpoint)
			throws IOException {
		super(buf, endpoint);
	}

	public void serialize(OutputBuffer buf) throws IOException {
		super.serialize(buf);
	}

	public void response(ApplicationPastryGrid App) {

        String ch="RDV"+from;

/****************Write in a file ***************************/

        FileOutputStream fop = null;
		File file;
		String content = ch; 
		try {
			file = new File("/home/RDV.txt");
			fop = new FileOutputStream(file);
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			// get the content in bytes
			byte[] contentInBytes = content.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fop != null) {
					fop.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
/****************************************************************/
		String line = "Searching nodes to execute first tasks of App: "
				+ appName;
		System.out.println(line);
		App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
				+ App.NPG.node.getId().hashCode() + "/history", line);
		Vector<TaskPastryGrid> W;
		W = App.getTasks(null, NodePastryGrid.submissionDirectory + time + "/"
				+ ApplicationPastryGrid.appXml);
		TaskPastryGrid predTask = new TaskPastryGrid();
		if (W.size() == 0) {
			System.out.println("There is no tasks to execute.");
			return;
		}
		Requirements R = W.get(0).getRequirements(
				NodePastryGrid.submissionDirectory + time + "/"
						+ ApplicationPastryGrid.appXml);
		LeafSet leafSet = ((PastryNode) App.NPG.node).getLeafSet();
		Vector<NodeHandle> H = new Vector<NodeHandle>();
		NodeHandle nh;

		int i = 1;
		if (App.NPG.submissionNodeCanWork)
			i = 0;
		for (; i <= leafSet.cwSize(); i++) {
			nh = leafSet.get(i);
			H.add(nh);
		}
		
		if(H.size()==0)
			System.err.println("There is no nodes to execute tasks");
		else{
			short TTL = 10;
			WorkRequest workrequest = new WorkRequest(App.NPG.node
					.getLocalNodeHandle(), appName, time, predTask, H, W, R, TTL);
			App.routeMyMsgDirect(workrequest, H.get(0));
		}
		

	}

	public short getType() {
		return TYPE;
	}
}
