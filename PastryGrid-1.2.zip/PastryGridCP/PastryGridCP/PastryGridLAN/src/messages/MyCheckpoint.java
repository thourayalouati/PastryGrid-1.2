package messages;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import principal.ApplicationPastryGrid;
import principal.NodePastryGrid;
import principal.TaskPastryGrid;
import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.NodeHandle;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;
import rice.pastry.Id;
import zip.Unzip;
import zip.Zip;

public class MyCheckpoint extends MessagePastryGrid {
	private static final long serialVersionUID = 1L;
	public static final short TYPE = 24;
	public TaskPastryGrid task;
	public boolean toRDV;
	public String filepath;

public MyCheckpoint(NodeHandle from, String appName, String time,
		TaskPastryGrid task, String filepath,boolean tordv) {
	super(from, appName, time);
	this.task = task;
	this.filepath = filepath;
	toRDV = tordv;
	
}
public MyCheckpoint(InputBuffer buf, Endpoint endpoint) throws IOException {
	super(buf, endpoint);
	task = TaskPastryGrid.readTaskPastryGrid(buf);
	filepath = "";
	toRDV = buf.readBoolean();
}

public void serialize(OutputBuffer buf) throws IOException {
	super.serialize(buf);
	task.serialize(buf);
	buf.writeBoolean(toRDV);
}
public void response(final ApplicationPastryGrid App) {
	
	System.out.println("Checkpoint received by the RDV !");	
	System.out.println("I'm the RDV "+App.NPG.node);
	new Thread() {
		public void run() {

	
			Unzip.unzip(NodePastryGrid.rdvDirectory+appName+time+"/"+
	            	  appName+"/"+task+"/CheckpointFiles"+".zip",
	            	  NodePastryGrid.rdvDirectory+appName+time+"/"+
	            	  appName+"/"+task+"/CheckpointFiles");}};
	}

	public short getType() {
		return TYPE;
	}

}
