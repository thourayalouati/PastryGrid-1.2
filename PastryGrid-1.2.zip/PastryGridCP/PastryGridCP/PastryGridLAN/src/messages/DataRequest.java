package messages;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import principal.ApplicationPastryGrid;
import principal.NodePastryGrid;
import principal.TaskPastryGrid;

import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.NodeHandle;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;
import rice.pastry.Id;
import zip.Zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DataRequest extends MessagePastryGrid {

	private static final long serialVersionUID = 1L;
	public static final short TYPE = 9;
	TaskPastryGrid task;
	Vector<String> inputs;

	short Ilength;

	public DataRequest(NodeHandle from, String appName, String time,
			TaskPastryGrid task, Vector<String> inputs) {
		super(from, appName, time);
		this.task = task;
		this.inputs = inputs;
	}

	public DataRequest(InputBuffer buf, Endpoint endpoint) throws IOException {
		super(buf, endpoint);

		task = TaskPastryGrid.readTaskPastryGrid(buf);
		Ilength = buf.readShort();
		inputs = new Vector<String>();
		for (int i = 0; i < Ilength; i++) {
			String s = buf.readUTF();
			inputs.add(s);
		}
	}

	public void serialize(OutputBuffer buf) throws IOException {
		super.serialize(buf);

		task.serialize(buf);
		Ilength = (short) inputs.size();
		buf.writeShort(Ilength);
		for (int i = 0; i < Ilength; i++)
			buf.writeUTF((String) inputs.get(i));
	}
	public static String listerRepertoire(File repertoire){ 
		String [] listefichiers; 
		listefichiers=repertoire.list(); 
		String max=listefichiers[0];
		return max;}
	 public static void copyFolder(File src, File dest)
    	throws IOException{
 
    	if(src.isDirectory()){
    		//if directory not exists, create it
    		if(!dest.exists()){
    		   dest.mkdir();
    		   System.out.println("Directory copied from " 
                              + src + "  to " + dest);
    		}
    		//list all the directory contents
    		String files[] = src.list();
    		for (String file : files) {
    		   //construct the src and dest file structure
    		   File srcFile = new File(src, file);
    		   File destFile = new File(dest, file);
    		   //recursive copy
    		   copyFolder(srcFile,destFile);
    		}
 
    	}else{
    		//if file, then copy it
    		//Use bytes stream to support all file types
    		InputStream in = new FileInputStream(src);
    	        OutputStream out = new FileOutputStream(dest); 
    	        byte[] buffer = new byte[1024];
    	        int length;
    	        //copy the file content in bytes 
    	        while ((length = in.read(buffer)) > 0){
    	    	   out.write(buffer, 0, length);
    	        }
    	        in.close();
    	        out.close();
    	        System.out.println("File copied from " + src + " to " + dest);
    	}}
		
	public void response(final ApplicationPastryGrid App) {

    /*****************************************************************/
		final String xmlFilePath = NodePastryGrid.rdvDirectory + appName + time + "/"
				+ appName + "/" + ApplicationPastryGrid.appXml;
        
		System.out.println("binary"+NodePastryGrid.rdvDirectory+appName+time+"/"+appName+task.BinaryDir(xmlFilePath)+task.BinaryName(xmlFilePath));
		//Path of CheckpointFiles
		String path=NodePastryGrid.rdvDirectory+appName+time+"/"+appName+"/"+task;
		System.out.println("Path of Checkpoint"+path);
		File f = new File (path);
		if (!f.exists()){
			System.out.println("Checkpoint directory does not found");
		new Thread() {
			public void run() {
				/*
				 * if(!new File(App.NPG.rdvDirectory+appName+time).exists()){
				 * App.past.lookupRDV(App.NPG.node,
				 * App.NPG.rdvDirectory+appName+time+".zip",
				 * App.NPG.node.getEnvironment()); App.NPG.sleep(3);
				 * Unzip.unzip(App.NPG.rdvDirectory+appName+time+".zip",
				 * App.NPG.rdvDirectory); }
				 */
				if (inputs.size() == 0)
					inputs = task.getInputFile(xmlFilePath);
				else {
					Vector<String> allinputs = task.getInputFile(xmlFilePath);
					for (int i = 0; i < inputs.size(); i++)
						for (int j = 0; j < allinputs.size(); j++)
							if (inputs.get(i).compareToIgnoreCase(
									allinputs.get(j)) == 0) {
								allinputs.remove(j);
								break;
							}
					inputs = allinputs;
				}

		/*		new Thread() {
					public void run() {
		*/				System.out.println("TriggerSupervision " + task.getName());
						TriggerSupervision triggersupervision = new TriggerSupervision(
								App.NPG.node.getLocalNodeHandle(), appName,
								time, from, task);
						Id idFtc = Id.build(appName + time + "FTC");
						App.routeMyMsg(triggersupervision, idFtc);
						App.NPG.sleep(1);
		/*			}
				}.start();
*/
				// zip files then send
				Vector<String> files = new Vector<String>();
				String taskFolderName = NodePastryGrid.rdvDirectory + appName + time
						+ "/" + appName + "/" + task.getName();
				File taskFolder = new File(taskFolderName);
				taskFolder.mkdirs();

				String dirResults = NodePastryGrid.rdvDirectory + appName + time + "/"
						+ appName + "/results/";
				for (int i = 0; i < inputs.size(); i++)
					//Zip.copyFile(new File(dirResults + inputs.get(i)), taskFolder); // +"/inputs"
					files.add(dirResults + inputs.get(i));

				String fileIn = NodePastryGrid.rdvDirectory + appName + time + "/"
						+ appName + task.getDirIn(xmlFilePath)
						+ task.getFileIn(xmlFilePath);
				files.add(fileIn);
				//Zip.copyFile(new File(fileIn), taskFolder);

				String binary = NodePastryGrid.rdvDirectory + appName + time + "/"
						+ appName + task.BinaryDir(xmlFilePath)
						+ task.BinaryName(xmlFilePath);
				files.add(binary);
				//Zip.copyFile(new File(binary), taskFolder);

				// create Task.xml
				task.generateTaskXml(xmlFilePath, taskFolderName);
				files.add(taskFolderName+"/Task.xml");

				String zipTaskName = NodePastryGrid.rdvDirectory + appName + time
						+ "/" + appName + "/" + task.getName() + ".zip";
			/*	String[] listFiles = taskFolder.list();
				for (int i = 0; i < listFiles.length; i++) {
					String filename = listFiles[i];
					listFiles[i] = taskFolderName + "/" + filename;
				}
*/
				String[] listFiles = new String[files.size()];
				files.copyInto(listFiles);
	//			for (int i = 0; i < listFiles.length; i++)
	//				System.out.println(listFiles[i]);
				Zip.zipFiles(zipTaskName, listFiles);
				// Zip.zipDir(zipTaskName, taskFolderName);
				
				String line = "Sending task's data: " + task + " to " + from;
				System.out.println(line);
				App.NPG.updateHistoryFile(NodePastryGrid.rdvDirectory + appName + time
						+ "/history", line);

				YourData yourdata = new YourData(App.NPG.node
						.getLocalNodeHandle(), appName, time, task, zipTaskName);
				//App.routeMyMsgDirect(yourdata, from);
				App.sendFile(yourdata, from);
				//System.out.println("Data sent.");
/*				while (taskFolder.exists()) {
					Zip.deleteDir(taskFolder);
					App.NPG.sleep(3);
				}
*/
		}
		}.start();
		}
		else 
		{      /*********************Sending Checkpoint Data AND TriggerSupervision ******************************************/
		
		        System.out.println("Checkpoint directory exist");
		        System.out.println("TriggerSupervision " + task.getName());
				TriggerSupervision triggersupervision = new TriggerSupervision(
				App.NPG.node.getLocalNodeHandle(), appName,
				time, from, task);
				Id idFtc = Id.build(appName + time + "FTC");
				App.routeMyMsg(triggersupervision, idFtc);
				App.NPG.sleep(1);
            
			String repchkpt=NodePastryGrid.rdvDirectory+appName+time+"/"+appName+"/"+task+"/CheckpointFiles/Checkpoint";
			File rep = new File(repchkpt);
			String max=task+".blcr";
            System.out.println("task "+max);
            System.out.println("binary"+NodePastryGrid.rdvDirectory+appName+time+"/"+appName+task.BinaryDir(xmlFilePath)+task.BinaryName(xmlFilePath));
			String[] File={NodePastryGrid.rdvDirectory+appName+time+"/"+appName+"/"+task+"/CheckpointFiles/Checkpoint/"+max,NodePastryGrid.rdvDirectory+appName+time+"/"+appName+task.BinaryDir(xmlFilePath)+task.BinaryName(xmlFilePath),NodePastryGrid.rdvDirectory+appName+time+"/"+appName+"/"+task+"/Task.xml"};
			String zipCkptName=NodePastryGrid.rdvDirectory + appName + time
			+ "/" + appName + "/" + task+"/CheckpointFiles/Checkpoint"+"/YRchkpt.zip";
			
			Zip.zipFiles(zipCkptName, File);
			YourCheckpoint yourcheckpoint=new YourCheckpoint(App.NPG.node
				.getLocalNodeHandle(), appName, time, task, zipCkptName);
			App.sendFile(yourcheckpoint,from);
			
		}

	}

	public short getType() {
		return TYPE;
	}
}
