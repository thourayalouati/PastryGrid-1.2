#!/bin/bash

echo "Local Backup"
mkdir $4/Checkpoint

/home/blcr-build/bin/cr_run $1 $2 $3  & my_pid=$!


while /home/blcr-build/bin/cr_checkpoint  -f $4/Checkpoint/$5.blcr $my_pid

do
	sleep 2
	

done
