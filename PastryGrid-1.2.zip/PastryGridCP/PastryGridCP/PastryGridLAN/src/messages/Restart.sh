#!/bin/bash

echo "Restart after failure + New Checkpointing"
mkdir $4/Checkpoint
/home/blcr-build/bin/cr_restart $2.blcr & my_pid=$!
echo $my_pid
echo "********************************Restart in Restart.sh****************************************************"

while /home/blcr-build/bin/cr_checkpoint  -f $4/Checkpoint/$3.blcr $my_pid
do
sleep 2
echo "******************************New Checkpointing**************************************************"
done
echo "Restart finished with succes !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
