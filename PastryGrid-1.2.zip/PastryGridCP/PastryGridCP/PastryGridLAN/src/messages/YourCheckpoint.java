package messages;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.Vector;

import principal.ApplicationPastryGrid;
import principal.NodePastryGrid;
import principal.Requirements;
import principal.TaskPastryGrid;

import rice.p2p.commonapi.Endpoint;
import rice.p2p.commonapi.NodeHandle;
import rice.p2p.commonapi.rawserialization.InputBuffer;
import rice.p2p.commonapi.rawserialization.OutputBuffer;
import rice.pastry.Id;
import rice.pastry.PastryNode;
import rice.pastry.leafset.LeafSet;
import zip.Unzip;
import zip.Zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.sql.Date;
public class YourCheckpoint extends MessagePastryGrid  {

	private static final long serialVersionUID = 1L;
	public static final short TYPE = 25;
	public TaskPastryGrid task;
	public String filepath;

	public YourCheckpoint(NodeHandle from, String appName, String time,
			TaskPastryGrid task, String filepath) {
		
		super(from, appName, time);
		this.task = task;
		this.filepath = filepath;
	}

	public YourCheckpoint(InputBuffer buf, Endpoint endpoint) throws IOException {
		
		super(buf, endpoint);
		task = TaskPastryGrid.readTaskPastryGrid(buf);
		filepath = "";
	}

	public void serialize(OutputBuffer buf) throws IOException {
		
		super.serialize(buf);
		task.serialize(buf);
	}
	public void runCommand(ApplicationPastryGrid App, String dirPath, String cmd) {
		try {
			

			Runtime runtime = Runtime.getRuntime();
			File directory = new File(dirPath);
			if(directory.exists())
				App.process = runtime.exec(cmd, null, directory);
			else
				App.process = runtime.exec(cmd);
			
			InputStream in = App.process.getInputStream();
			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);
			String line;

			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}

			InputStream err = App.process.getErrorStream();
			isr = new InputStreamReader(err);
			br = new BufferedReader(isr);
			while ((line = br.readLine()) != null) {
				System.out.println(line);
			}
			App.process.waitFor();
			App.process.destroy();
		} catch (Exception e) {
			System.out.println("Execution Error: " + cmd + " " + e.toString());
		}
	}
	public static String listerRepertoire(File repertoire){ 
		String [] listefichiers; 
		listefichiers=repertoire.list(); 
		String max=listefichiers[0];
		return max;
		}
    public static void copyFolder(File src, File dest)
    	throws IOException{
 
    	if(src.isDirectory()){
    		//if directory not exists, create it
    		if(!dest.exists()){
    		   dest.mkdir();
    		   System.out.println("Directory copied from " 
                              + src + "  to " + dest);
    		}
    		//list all the directory contents
    		String files[] = src.list();
    		for (String file : files) {
    		   //construct the src and dest file structure
    		   File srcFile = new File(src, file);
    		   File destFile = new File(dest, file);
    		   //recursive copy
    		   copyFolder(srcFile,destFile);
    		}
    	}else{
    		//if file, then copy it
    		//Use bytes stream to support all file types
    		InputStream in = new FileInputStream(src);
    	    OutputStream out = new FileOutputStream(dest); 
    	    byte[] buffer = new byte[1024];
    	    int length;
    	    //copy the file content in bytes 
    	    while ((length = in.read(buffer)) > 0){
    	    	out.write(buffer, 0, length);
    	        }
 
    	    in.close();
    	    out.close();
    	    System.out.println("File copied from " + src + " to " + dest);
    	}}
	public void executeTask1(final ApplicationPastryGrid App, String taskXmlPath) throws InterruptedException
	
	     {           

        String line = "Restarting task.. " + task.getName() + " - App: "
		+ appName + " - AppHandle: " + appName + time;
		System.out.println(line);
		App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
		+ App.NPG.node.getId().hashCode() + "/history", line);

		final String xmlFilePath = NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt/Task.xml" ;
		System.out.println(task.BinaryName(xmlFilePath));
		String source =NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt/"+task.BinaryName(xmlFilePath);
		String destination = NodePastryGrid.workDirectory + appName + time + "/"+task+"/"+task.BinaryName(xmlFilePath);
		File srcFolder = new File(source);
    		File destFolder = new File(destination);
		try{
        		copyFolder(srcFolder,destFolder);
           	   }catch(IOException e){
        			e.printStackTrace();
        	                System.exit(0);
                   }
		System.out.println("YRcheckpoint received");
	    //File f = new File(System.getProperty("user.home")+"/PastryGridLAN/src/messages/Restart.sh");
        File f = new File("/home/PastryGridLAN/src/messages/Restart.sh");
		f.setExecutable(true);
        f.setReadable(true);
		f.setWritable(true);
		final String rep2store=NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt" ;
		String rep2store1=NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt/"+task ;
        String rep=NodePastryGrid.workDirectory + appName + time + "/" + task;// rep ou on a rep checkpoint
	    //final String cmd=System.getProperty("user.home")+"/PastryGridLAN/src/messages/Restart.sh"+" "+rep2store+" "+rep2store1+" "+task+" "+rep;
		final String cmd="/home/PastryGridLAN/src/messages/Restart.sh"+" "+rep2store+" "+rep2store1+" "+task+" "+rep;
		final Thread thread2 = new Thread("New Thread2") 
		{
			public void run(){ 
					runCommand(App,  NodePastryGrid.workDirectory + appName + time + "/" + task, cmd);
                                         }
		};
		Thread thread3 = new Thread("New Thread3") 
	       {   
	    	public void run(){ 					
			                   int i=0;
			                       while(thread2.isAlive()==true)
			                        { 
			    						System.out.println("alive");
			    						
			                        	try {
			    							  App.NPG.environment.getTimeSource().sleep(20 * 1000);
					                        } catch (InterruptedException e) {
					                        									e.printStackTrace();
					                        								  }
					                        Zip.zipDir(NodePastryGrid.workDirectory + appName + time + "/" + task+"/ckpt"+i+".zip", NodePastryGrid.workDirectory + appName + time + "/" + task+"/Checkpoint");
				                        	System.out.println("Sending New After Restart Checkpoint...");
				                        	MyCheckpoint mycheckpoint=new MyCheckpoint(App.NPG.node.getLocalNodeHandle(),appName,time,task,NodePastryGrid.workDirectory + appName + time + "/" + task+"/ckpt"+i+".zip",true);
				                        	App.sendFile(mycheckpoint, from);
					                        i++;
                                           System.out.println("Sending New Checkpoint");
			                        }	                                	
		                        
	    }};

	    thread2.start();
	    thread3.start();
        thread2.join();
        
		
        long currentTime = System.currentTimeMillis();
        final String appTime1 = Long.toString(currentTime);
        Date date = new Date(currentTime); // if U really have long
        String result = new SimpleDateFormat("HH:mm:ss").format(date.getTime());
        String ch=task+"Time End "+result;
        FileOutputStream fop = null;
		File file;
		String content = ch;
		try {
 
			file = new File("/home/"+task+".txt");
			fop = new FileOutputStream(file);
			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			// get the content in bytes
			byte[] contentInBytes = content.getBytes();
			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (fop != null) {
					fop.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

        System.out.println("App.stoped"+App.stopped);
		if (App.stopped) {
			line = "Task cancelled: " + task.getName() + " - App: " + appName
					+ " - AppHandle: " + appName + time;
			System.out.println(line);
			App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
					+ App.NPG.node.getId().hashCode() + "/history", line);

			Vector<TaskPastryGrid> W = new Vector<TaskPastryGrid>();
			W.add(task);
			Requirements R = W.get(1).getRequirements(xmlFilePath);
			LeafSet leafSet = ((PastryNode) App.NPG.node).getLeafSet();
			Vector<NodeHandle> H = new Vector<NodeHandle>();
			NodeHandle nh;
			for (int i = 0; i <= leafSet.cwSize(); i++) {
				if (i != 0) { // don't send to self
					nh = leafSet.get(i);
					H.add(nh);
				}
			}
			short TTL = 10;
			WorkRequest workrequest = new WorkRequest(App.NPG.node
					.getLocalNodeHandle(), appName, time, new TaskPastryGrid(),
					H, W, R, TTL);
			App.routeMyMsgDirect(workrequest, H.get(0));
			App.NPG.sleep(1);

			WorkRequest.taskToExecute = null;
			App.stopped = false;
			App.process = null;
			App.idle = true;

			return;
		}

		line = "Finish executing task: " + task.getName() + " - App: "
				+ appName + " - AppHandle: " + appName + time;
		System.out.println(line);
		App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
				+ App.NPG.node.getId().hashCode() + "/history", line);
		// send result to rdv
	/*	new Thread() {
			public void run() {
*/
        System.out.println("Stop Supervision "+task);
        Id idFtc = Id.build(appName + time + "FTC");
        System.out.println("idftc"+idFtc);   
        WorkDone workdone = new WorkDone(App.NPG.node
        .getLocalNodeHandle(), appName, time, task);
        App.routeMyMsg(workdone, idFtc);

        
				String output = task.getOutputFile(xmlFilePath);
				String outputFilePath = NodePastryGrid.workDirectory + appName + time
						+ "/" + task + "/" + output;
			
				if (new File(outputFilePath).exists()) {
					line = "Task: " + task.getName()
							+ " sending result to rdv: " + output;
					System.out.println(line);
					App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
							+ App.NPG.node.getId().hashCode() + "/history",
							line);
					String[] filesPath = { outputFilePath };
					outputFilePath = NodePastryGrid.workDirectory + appName + time
							+ "/" + task + "/" + "output.zip";
					Zip.zipFiles(outputFilePath, filesPath);
					MyResult myresult = new MyResult(App.NPG.node
							.getLocalNodeHandle(), appName, time, task,
							outputFilePath, true);
					//App.routeMyMsgDirect(myresult, from);
					App.sendFile(myresult, from);				
					while(!App.transfertComplete){
						//System.out.println("not yet");
						App.NPG.sleep(1);
					}
						
					App.transfertComplete = false;
				} else {
					System.out.println("Error output: " + outputFilePath
							+ " not found");
				}
	
		// extract succtasks
		Vector<TaskPastryGrid> W = task.getIsolatedSucc(xmlFilePath);

		if (task.getSharedSucc(xmlFilePath).size() > 0){
			line = "Search request task: " + task.getName();
			System.out.println(line);
			App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
					+ App.NPG.node.getId().hashCode() + "/history",
					line);
			SearchRequest searchrequest = new SearchRequest(
					App.NPG.node.getLocalNodeHandle(), appName, time,
					task);
			App.routeMyMsgDirect(searchrequest, from);
		}
		
		if (W.size() > 0) {
			// work request for the isolated tasks
			line = "task: " + task.getName() + " W.size= " + W.size();
			System.out.println(line);
			App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
					+ App.NPG.node.getId().hashCode() + "/history", line);
			Requirements R = W.get(0).getRequirements(xmlFilePath);
			LeafSet leafSet = ((PastryNode) App.NPG.node).getLeafSet();
			Vector<NodeHandle> H = new Vector<NodeHandle>();
			NodeHandle nh;
			for (int i = 0; i <= leafSet.cwSize(); i++) {
				// if (i != 0) { // don't send to self
				nh = leafSet.get(i);
				H.add(nh);
				// }
			}
			short TTL = 10;
			WorkRequest workrequest = new WorkRequest(App.NPG.node
					.getLocalNodeHandle(), appName, time, task, H, W, R, TTL);
			App.routeMyMsgDirect(workrequest, H.get(0));
			App.NPG.sleep(1);
		}

		WorkRequest.taskToExecute = null;
		App.idle = true;
		System.out.println("I'm free");	
		
	}
	public void response(final ApplicationPastryGrid App) {
           
   		    String taskFolder = NodePastryGrid.workDirectory + appName + time + "/"
						+ task;
            /****************************************************************************/

                String line = "Restarting Task.. : " + task.getName() + " - App: "
                                + appName + " - AppHandle: " + appName + time;
                System.out.println(line);
                App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
                                + App.NPG.node.getId().hashCode() + "/history", line);


                final String xmlFilePath = NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt/Task.xml" ;
                System.out.println(task.BinaryName(xmlFilePath));
                String source =NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt/"+task.BinaryName(xmlFilePath);
                String destination = NodePastryGrid.workDirectory + appName + time + "/"+task+"/"+task.BinaryName(xmlFilePath);
                File srcFolder = new File(source);
                File destFolder = new File(destination);
                try{
                        copyFolder(srcFolder,destFolder);
                   }catch(IOException e){
                                e.printStackTrace();
                                System.exit(0);
                   }
                System.out.println("YRcheckpoint reçu");
               // File f = new File(System.getProperty("user.home")+"/PastryGridLAN/src/messages/Restart.sh");
                File f = new File("/home/PastryGridLAN/src/messages/Restart.sh");
                f.setExecutable(true);
                f.setReadable(true);
                f.setWritable(true);
                final String rep2store=NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt" ;
                String rep2store1=NodePastryGrid.workDirectory + appName + time + "/" + task+"/YRchkpt/"+task ;
                String rep=NodePastryGrid.workDirectory + appName + time + "/" + task;// rep ou on a rep checkpoint
                final String cmd="/home/PastryGridLAN/src/messages/Restart.sh"+" "+rep2store+" "+rep2store1+" "+task+" "+rep;
                final Thread thread2 = new Thread("New Thread2")
                {
                        public void run(){
                                        runCommand(App,  NodePastryGrid.workDirectory + appName + time + "/" + task, cmd);
                /**********************************************/
                Id idFtc = Id.build(appName + time + "FTC");
                System.out.println("iftc"+idFtc);
                WorkDone workdone = new WorkDone(App.NPG.node
                                                .getLocalNodeHandle(), appName, time, task);
                App.routeMyMsg(workdone, idFtc);

                String output = task.getOutputFile(xmlFilePath);
                                String outputFilePath = NodePastryGrid.workDirectory + appName + time
                                                + "/" + task + "/" + output;

                                if (new File(outputFilePath).exists()) {
                                 String        line = "Task: " + task.getName()
                                                        + " sending result to rdv: " + output;
                                        System.out.println(line);
                                        App.NPG.updateHistoryFile(NodePastryGrid.nodeDirectory
                                                        + App.NPG.node.getId().hashCode() + "/history",
                                                        line);
                                        String[] filesPath = { outputFilePath };
                                        outputFilePath = NodePastryGrid.workDirectory + appName + time
                                                        + "/" + task + "/" + "output.zip";
                                        Zip.zipFiles(outputFilePath, filesPath);
                                        MyResult myresult = new MyResult(App.NPG.node
                                                        .getLocalNodeHandle(), appName, time, task,
                                                        outputFilePath, true);
                                        //App.routeMyMsgDirect(myresult, from);
                                        App.sendFile(myresult, from);
                                        while(!App.transfertComplete){
                                                //System.out.println("not yet");
                                                App.NPG.sleep(1);
                                        }

                                        App.transfertComplete = false;
                                } else {
                                        System.out.println("Error output: " + outputFilePath
                         + " not found");
                                }

                long currentTime = System.currentTimeMillis();
                final String appTime1 = Long.toString(currentTime);
                Date date = new Date(currentTime); 
                String result = new SimpleDateFormat("HH:mm:ss").format(date.getTime());
                String ch=task+"Time End.. "+result;
                FileOutputStream fop = null;
                File file;
                String content = ch;

                try {

                        file = new File("/home/"+task+".txt");
                        fop = new FileOutputStream(file);
                        // if file doesnt exists, then create it
                        if (!file.exists()) {
                                file.createNewFile();
                        }
                        // get the content in bytes
                        byte[] contentInBytes = content.getBytes();
                        fop.write(contentInBytes);
                        fop.flush();
                        fop.close();
                        System.out.println("Done");

                } catch (IOException e) {
                        e.printStackTrace();
                } finally {
                        try {
                                if (fop != null) {
                                        fop.close();
                                }
                        } catch (IOException e) {
                                e.printStackTrace();
                        }
                }

                                         }
                };
                Thread thread3 = new Thread("New Thread3")
               {
                public void run(){


                                           int i=0;
                                               while(thread2.isAlive()==true)
                                                {
                                                                System.out.println("alive");

                                                        try {
                                                                                  App.NPG.environment.getTimeSource().sleep(20 * 1000);
                                                                } catch (InterruptedException e) {
                                                                                                                                        e.printStackTrace();
                                                                                                                                  }
                                                                Zip.zipDir(NodePastryGrid.workDirectory + appName + time + "/" + task+"/ckpt"+i+".zip", NodePastryGrid.workDirectory + appName + time + "/" + task+"/Checkpoint");
                                                                System.out.println("Sending New Checkpoint after restart...");
                                                                MyCheckpoint mycheckpoint=new MyCheckpoint(App.NPG.node.getLocalNodeHandle(),appName,time,task,NodePastryGrid.workDirectory + appName + time + "/" + task+"/ckpt"+i+".zip",true);
                                                                App.sendFile(mycheckpoint, from);
                                                                i++;
                                                                
                                                }

            }};

            thread2.start();
            thread3.start();
            //thread2.join();
	}
	
	public short getType() {
		return TYPE;
	}
	
	}
	

